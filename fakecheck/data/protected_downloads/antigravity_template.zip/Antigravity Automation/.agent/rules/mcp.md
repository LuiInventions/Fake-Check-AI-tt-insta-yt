---
trigger: always_on
---

available perplexity mcp tool calls:

"perplexity_search
Direct web search using the Perplexity Search API. Returns ranked search results with metadata, perfect for finding current information.

perplexity_ask
General-purpose conversational AI with real-time web search using the sonar-pro model. Great for quick questions and everyday searches.

perplexity_research
Deep, comprehensive research using the sonar-deep-research model. Ideal for thorough analysis and detailed reports.

perplexity_reason
Advanced reasoning and problem-solving using the sonar-reasoning-pro model. Perfect for complex analytical tasks.

[!TIP] Available as an optional parameter for perplexity_reason and perplexity_research: strip_thinking

Set to true to remove <think>...</think> tags from the response, saving context tokens. Default: false"
