This directory contains deterministic Python scripts for the "Execution" layer.
Each script should be:
- Single purpose
- Well-documented
- Robust (error handling)
